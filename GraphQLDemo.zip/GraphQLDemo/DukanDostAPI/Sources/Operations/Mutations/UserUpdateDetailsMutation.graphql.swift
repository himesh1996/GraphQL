// @generated
// This file was automatically generated and should not be edited.

@_exported import ApolloAPI

public class UserUpdateDetailsMutation: GraphQLMutation {
  public static let operationName: String = "UserUpdateDetails"
  public static let operationDocument: ApolloAPI.OperationDocument = .init(
    definition: .init(
      #"mutation UserUpdateDetails($id: ID!, $name: String!) { userUpdateDetails(_id: $id, name: $name) { __typename message data { __typename _id email name } } }"#
    ))

  public var id: ID
  public var name: String

  public init(
    id: ID,
    name: String
  ) {
    self.id = id
    self.name = name
  }

  public var __variables: Variables? { [
    "id": id,
    "name": name
  ] }

  public struct Data: DukanDostAPI.SelectionSet {
    public let __data: DataDict
    public init(_dataDict: DataDict) { __data = _dataDict }

    public static var __parentType: any ApolloAPI.ParentType { DukanDostAPI.Objects.Mutation }
    public static var __selections: [ApolloAPI.Selection] { [
      .field("userUpdateDetails", UserUpdateDetails.self, arguments: [
        "_id": .variable("id"),
        "name": .variable("name")
      ]),
    ] }

    public var userUpdateDetails: UserUpdateDetails { __data["userUpdateDetails"] }

    /// UserUpdateDetails
    ///
    /// Parent Type: `UserResponseDto`
    public struct UserUpdateDetails: DukanDostAPI.SelectionSet {
      public let __data: DataDict
      public init(_dataDict: DataDict) { __data = _dataDict }

      public static var __parentType: any ApolloAPI.ParentType { DukanDostAPI.Objects.UserResponseDto }
      public static var __selections: [ApolloAPI.Selection] { [
        .field("__typename", String.self),
        .field("message", String.self),
        .field("data", Data.self),
      ] }

      public var message: String { __data["message"] }
      public var data: Data { __data["data"] }

      /// UserUpdateDetails.Data
      ///
      /// Parent Type: `UserDetailDto`
      public struct Data: DukanDostAPI.SelectionSet {
        public let __data: DataDict
        public init(_dataDict: DataDict) { __data = _dataDict }

        public static var __parentType: any ApolloAPI.ParentType { DukanDostAPI.Objects.UserDetailDto }
        public static var __selections: [ApolloAPI.Selection] { [
          .field("__typename", String.self),
          .field("_id", DukanDostAPI.ID.self),
          .field("email", String.self),
          .field("name", String.self),
        ] }

        public var _id: DukanDostAPI.ID { __data["_id"] }
        public var email: String { __data["email"] }
        public var name: String { __data["name"] }
      }
    }
  }
}
