// @generated
// This file was automatically generated and should not be edited.

@_exported import ApolloAPI

public class UserLoginQuery: GraphQLQuery {
  public static let operationName: String = "UserLogin"
  public static let operationDocument: ApolloAPI.OperationDocument = .init(
    definition: .init(
      #"query UserLogin($phoneNumber: Float!, $platformType: String!, $deviceType: String, $deviceToken: String) { userLogin( phoneNumber: $phoneNumber platformType: $platformType deviceType: $deviceType deviceToken: $deviceToken ) { __typename code message data { __typename _id email phoneNumber businessName name token } } }"#
    ))

  public var phoneNumber: Double
  public var platformType: String
  public var deviceType: GraphQLNullable<String>
  public var deviceToken: GraphQLNullable<String>

  public init(
    phoneNumber: Double,
    platformType: String,
    deviceType: GraphQLNullable<String>,
    deviceToken: GraphQLNullable<String>
  ) {
    self.phoneNumber = phoneNumber
    self.platformType = platformType
    self.deviceType = deviceType
    self.deviceToken = deviceToken
  }

  public var __variables: Variables? { [
    "phoneNumber": phoneNumber,
    "platformType": platformType,
    "deviceType": deviceType,
    "deviceToken": deviceToken
  ] }

  public struct Data: DukanDostAPI.SelectionSet {
    public let __data: DataDict
    public init(_dataDict: DataDict) { __data = _dataDict }

    public static var __parentType: any ApolloAPI.ParentType { DukanDostAPI.Objects.Query }
    public static var __selections: [ApolloAPI.Selection] { [
      .field("userLogin", UserLogin.self, arguments: [
        "phoneNumber": .variable("phoneNumber"),
        "platformType": .variable("platformType"),
        "deviceType": .variable("deviceType"),
        "deviceToken": .variable("deviceToken")
      ]),
    ] }

    public var userLogin: UserLogin { __data["userLogin"] }

    /// UserLogin
    ///
    /// Parent Type: `UserLogin`
    public struct UserLogin: DukanDostAPI.SelectionSet {
      public let __data: DataDict
      public init(_dataDict: DataDict) { __data = _dataDict }

      public static var __parentType: any ApolloAPI.ParentType { DukanDostAPI.Objects.UserLogin }
      public static var __selections: [ApolloAPI.Selection] { [
        .field("__typename", String.self),
        .field("code", Double.self),
        .field("message", String.self),
        .field("data", Data.self),
      ] }

      public var code: Double { __data["code"] }
      public var message: String { __data["message"] }
      public var data: Data { __data["data"] }

      /// UserLogin.Data
      ///
      /// Parent Type: `UserDetailDto`
      public struct Data: DukanDostAPI.SelectionSet {
        public let __data: DataDict
        public init(_dataDict: DataDict) { __data = _dataDict }

        public static var __parentType: any ApolloAPI.ParentType { DukanDostAPI.Objects.UserDetailDto }
        public static var __selections: [ApolloAPI.Selection] { [
          .field("__typename", String.self),
          .field("_id", DukanDostAPI.ID.self),
          .field("email", String.self),
          .field("phoneNumber", Double.self),
          .field("businessName", String?.self),
          .field("name", String.self),
          .field("token", String?.self),
        ] }

        public var _id: DukanDostAPI.ID { __data["_id"] }
        public var email: String { __data["email"] }
        public var phoneNumber: Double { __data["phoneNumber"] }
        public var businessName: String? { __data["businessName"] }
        public var name: String { __data["name"] }
        public var token: String? { __data["token"] }
      }
    }
  }
}
