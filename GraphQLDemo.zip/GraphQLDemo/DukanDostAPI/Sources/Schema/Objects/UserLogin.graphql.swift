// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  static let UserLogin = ApolloAPI.Object(
    typename: "UserLogin",
    implementedInterfaces: []
  )
}