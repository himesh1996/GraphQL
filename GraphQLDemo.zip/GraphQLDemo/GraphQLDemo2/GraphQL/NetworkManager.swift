//
//  NetworkManager.swift
//  GraphQLDemo2
//
//  Created by Himesh on 17/07/24.
//

import Foundation
import Apollo
import ApolloAPI


class NetworkManager {
    
    static let shared = NetworkManager()
    
    private init() {}
    
    private(set) lazy var apollo: ApolloClient = {
        
        let token = UserDefaults.standard.string(forKey: "accessToken") ?? ""
        
        let cache = InMemoryNormalizedCache()
        let store = ApolloStore(cache: cache)
        let url = URL(string: "https://dukaandost-api.apps.openxcell.dev/graphql")!
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = ["token": "\(token)"]
        
        let client = URLSessionClient(sessionConfiguration: configuration, callbackQueue: nil)
        let provider = NetworkInterceptorProvider(client: client, shouldInvalidateClientOnDeinit: true, store: store)
        let requestChainTransport = RequestChainNetworkTransport(interceptorProvider: provider, endpointURL: url)
        return ApolloClient(networkTransport: requestChainTransport, store: store)
        
        //private(set) lazy var apollo = ApolloClient(url: URL(string: "https://dukaandost-api.apps.openxcell.dev/graphql")!)
    }()
}

class NetworkInterceptorProvider: DefaultInterceptorProvider {
    override func interceptors<Operation: GraphQLOperation>(for operation: Operation) -> [ApolloInterceptor] {
        var interceptors = super.interceptors(for: operation)
        interceptors.insert(CustomInterceptor(), at: 0)
        return interceptors
    }
}

class CustomInterceptor: ApolloInterceptor {
    var id: String = ""
    
    func interceptAsync<Operation: GraphQLOperation>(
        chain: RequestChain,
        request: HTTPRequest<Operation>,
        response: HTTPResponse<Operation>?,
        completion: @escaping (Swift.Result<GraphQLResult<Operation.Data>, Error>) -> Void) {
            request.addHeader(name: "Authorization", value: "Bearer <<TOKEN>>")
            
            print("request :\(request)")
            print("response :\(String(describing: response))")
            
            chain.proceedAsync(request: request,
                               response: response,
                               completion: completion)
        }
}
