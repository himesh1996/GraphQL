//
//  ViewController.swift
//  GraphQLDemo2
//
//  Created by Himesh on 17/07/24.
//

import UIKit
import DukanDostAPI

class ViewController: UIViewController {
    
    let loginUserViewModel = LoginViewModel()
    let updateUserViewModel = UpdateUserViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        onloadOperation()
    }
    
    func onloadOperation() {
        loginUserViewModel.delegate = self
        updateUserViewModel.delegate = self
        loginUserViewModel.userLoginAPI()
    }
}

extension ViewController: LoginViewModelDelegate {
    
    func didReceiveResposne() {
        print("++++++++ Login Response ++++++++")
        print(loginUserViewModel.userData?._id ?? "")
        print(loginUserViewModel.userData?.email ?? "")
        print(loginUserViewModel.userData?.name ?? "")
        print("=========================")
        UserDefaults.standard.setValue(loginUserViewModel.userData?.token ?? "", forKey: "accessToken")
        updateUserViewModel.UserUpdateDetailAPI(id: loginUserViewModel.userData?._id ?? "", name: "Tulsi K")
    }
    
    func didReceiveFailure(errorMessage: String) {
        print(errorMessage)
    }
    
}

extension ViewController: UpdateUserViewModelDelegate {
    
    func didReceiveUpdateUserResposne() {
        print("++++++++ Update User Response ++++++++")
        print(updateUserViewModel.userData?._id ?? "")
        print(updateUserViewModel.userData?.email ?? "")
        print(updateUserViewModel.userData?.name ?? "")
        print("=========================")
    }
    
    func didFailedUpdateUser(errorMessage: String) {
        print(errorMessage)
    }
    
}
