//
//  LoginViewModel.swift
//  GraphQLDemo2
//
//  Created by Himesh on 18/07/24.
//

import Foundation
import Apollo
import DukanDostAPI


protocol LoginViewModelDelegate: AnyObject {
    func didReceiveResposne()
    func didReceiveFailure(errorMessage: String)
}

class LoginViewModel {
    
    weak var delegate: LoginViewModelDelegate?
    var userData: UserLoginQuery.Data.UserLogin.Data?
    
    func userLoginAPI() {
        NetworkManager.shared.apollo.fetch(query: UserLoginQuery(phoneNumber: 9876543210, platformType: "APP", deviceType: "iOS", deviceToken: "naoisfojasdofmowedfjejwpf6456w4f4w6ef6wef")) { [weak self] result in
            switch result {
            case .success(let graphQLResult):
                guard let resultData = graphQLResult.data else {
                    self?.delegate?.didReceiveFailure(errorMessage: "Failed to parse the data")
                    return
                }
                self?.userData = resultData.userLogin.data
                self?.delegate?.didReceiveResposne()
            case .failure(let error):
                self?.delegate?.didReceiveFailure(errorMessage: error.localizedDescription)
            }
        }
    }
}
