//
//  UpdateUserViewModel.swift
//  GraphQLDemo2
//
//  Created by Himesh on 18/07/24.
//

import Foundation
import Apollo
import DukanDostAPI

protocol UpdateUserViewModelDelegate: AnyObject {
    func didReceiveUpdateUserResposne()
    func didFailedUpdateUser(errorMessage: String)
}

class UpdateUserViewModel {
    
    weak var delegate: UpdateUserViewModelDelegate?
    var userData: UserUpdateDetailsMutation.Data.UserUpdateDetails.Data?
    
    func UserUpdateDetailAPI(id: String, name: String) {
        NetworkManager.shared.apollo.perform(mutation: UserUpdateDetailsMutation(id: id, name: name)) { [weak self] result in
            switch result {
            case .success(let graphQLResult):
                guard let resultData = graphQLResult.data else {
                    self?.delegate?.didFailedUpdateUser(errorMessage: "Failed to parse json")
                    return
                }
                self?.userData = resultData.userUpdateDetails.data
                self?.delegate?.didReceiveUpdateUserResposne()
            case .failure(let error):
                self?.delegate?.didFailedUpdateUser(errorMessage: error.localizedDescription)
            }
        }
    }
}
